import { Component, Vue } from "vue-property-decorator";

@Component
export default class DialogosComponentClass extends Vue {
  private dialog: boolean = false;
}
