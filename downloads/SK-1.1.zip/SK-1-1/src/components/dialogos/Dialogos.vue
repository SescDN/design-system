<template src="@/components/dialogos/dialogos.html"></template>

<script lang="ts" src="@/components/dialogos/dialogos.ts"></script>

<style lang="scss" src="@/components/dialogos/dialogos.scss"></style>
