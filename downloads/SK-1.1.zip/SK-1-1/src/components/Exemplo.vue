<template src="Exemplo.vue.html" />
<script src="Exemplo.vue.ts" lang="ts" />
<style lang="scss" src="Exemplo.vue.scss" />





